<?php

include 'connection.php';
session_start();
$nocopies=$_POST['copy'];
$papersize=$_POST['category'];
$printtype=$_POST['category1'];
$note=$_POST['message'];
$folder=$_SESSION['id'];




$fname=$_FILES['myfile']['name'];
$tname=$_FILES['myfile']['tmp_name'];
$filetype=$_FILES['myfile']['type'];
//$fsize=$_FILES['myflie']['size'];
$dir=$_SESSION['id'].".pdf";
$loc='pending';
$query="INSERT INTO UPLOAD(ACCOUNT,PAPERSIZE,PRINTTYPE,NOTE,COPIES,LOCATION)VALUES('$folder','$papersize','$printtype','$note','$nocopies','$loc')";
$run=mysqli_query($connection,$query) or die('Error'.mysqli_error($connection));
if(isset($fname))
{ 
    if(!empty($fname))
    {  
        
        $location="'pending/'$folder'/.'";
       if(move_uploaded_file($tname,'pending/'.$dir)){
            echo("File has be successfully uploaded");
           header("location:logout.php");
       }
        else{
            echo("Error while uploading");
        }
           
    }
}


/*if($fsize>10485760)
{
    echo("<script>alert('Flie size should not exceed 10 mb')</script>");
  Y  
}*/


?>